import os
from fastapi import FastAPI, Header, HTTPException
from fastapi.responses import HTMLResponse
app=FastAPI(title="Artemide Core API",version="0.5.0")
API_KEY=os.getenv("ARTEMIDE_API_KEY","")
@app.get("/health")
def health(): return {"status":"ok","model":"Artemide Core","generation_ready":False}
def auth(key):
    if not API_KEY or key!=f"Bearer {API_KEY}": raise HTTPException(401,"Valid API key required")
@app.get("/v1/metrics")
def metrics(authorization: str|None=Header(default=None)):
    auth(authorization)
    try:
        with open("runs/metrics.jsonl",encoding="utf-8") as f: rows=[__import__("json").loads(x) for x in f if x.strip()]
    except FileNotFoundError: rows=[]
    return {"points":rows[-500:]}
@app.post("/v1/generate")
def generate(authorization: str|None=Header(default=None)):
    auth(authorization)
    raise HTTPException(503,"Inference checkpoint loader and serving policy are not configured; no synthetic response is returned.")
@app.get("/dashboard",response_class=HTMLResponse)
def dashboard():
    try: return open("dashboard/index.html",encoding="utf-8").read()
    except FileNotFoundError: return "<h1>Artemide training dashboard</h1>"

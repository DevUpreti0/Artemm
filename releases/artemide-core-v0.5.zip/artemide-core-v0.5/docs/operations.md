# Operations (v0.5)

Install with `pip install -e '.[test]'`. Run `pytest -q`.
Train with `artemide-train --config configs/small.json --steps 100`.
Set `ARTEMIDE_API_KEY` before running `uvicorn api.main:app`.
`GET /health` is public. Metrics require bearer authentication.
Generation intentionally returns HTTP 503 until a tested inference loader and serving
policy are implemented. Training currently uses random token batches as a smoke-test
loop; connect a licensed, curated corpus before meaningful model training.

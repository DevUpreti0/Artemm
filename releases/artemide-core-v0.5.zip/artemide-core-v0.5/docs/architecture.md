# Artemide Core architecture (v0.4)

This research baseline is initialized from random weights. It uses a byte tokenizer,
decoder-only causal Transformer blocks, RoPE, grouped-query attention, RMSNorm,
SwiGLU feed-forward layers, tied token embeddings and residual output scaling.
Optional gradient checkpointing is represented in configuration for later training
integration. This is not a production-scale foundation model.

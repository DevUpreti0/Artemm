# Artemide Core v0.5.0

Cumulative operations and training upgrade over the reconstructed v0.4 baseline.
Includes warmup/cosine learning-rate scheduling, atomic checkpoints, JSONL telemetry,
a held-out evaluation CLI, authenticated FastAPI metrics, and a dark responsive
training monitor.

## Install and test
`pip install -e '.[test]'`
`pytest -q`

## Run a smoke training loop
`artemide-train --config configs/small.json --steps 100`
Then inspect `runs/metrics.jsonl`, `runs/latest.pt`, and `runs/final.pt`.

## API
Set `ARTEMIDE_API_KEY` and run `uvicorn api.main:app --host 0.0.0.0 --port 8000`.
`GET /health` is public. `/v1/metrics` requires bearer auth.
`POST /v1/generate` intentionally returns 503 until a real checkpoint-loading
inference runtime and serving policy are implemented. The API never fabricates output.

## Important limitations
The included training loop is a pipeline smoke test using random token batches,
not a meaningful language-model corpus trainer. Supply lawful, curated data and
implement a production data loader, validation, safety, and inference before release.
This package is reconstructed from retained project specifications; it is not
represented as the missing original v0.4/v0.5 archive.

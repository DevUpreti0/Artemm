class ByteTokenizer:
    """Stable byte tokenizer with reserved IDs; intentionally simple baseline."""
    pad_id, bos_id, eos_id = 0, 1, 2
    vocab_size = 259
    def encode(self, text, add_bos=False, add_eos=False):
        ids = [b+3 for b in text.encode("utf-8")]
        return ([self.bos_id] if add_bos else []) + ids + ([self.eos_id] if add_eos else [])
    def decode(self, ids):
        return bytes(i-3 for i in ids if 3 <= i < 259).decode("utf-8", errors="replace")

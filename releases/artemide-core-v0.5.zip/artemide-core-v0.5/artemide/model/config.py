from dataclasses import dataclass, asdict
import json

@dataclass
class ModelConfig:
    vocab_size: int = 260
    d_model: int = 256
    n_layers: int = 6
    n_heads: int = 8
    n_kv_heads: int = 4
    max_seq_len: int = 512
    dropout: float = 0.0
    rope_theta: float = 10000.0
    gradient_checkpointing: bool = False

    def __post_init__(self):
        if self.d_model % self.n_heads:
            raise ValueError("d_model must be divisible by n_heads")
        if self.n_heads % self.n_kv_heads:
            raise ValueError("n_heads must be divisible by n_kv_heads")
        if self.d_model <= 0 or self.n_layers <= 0 or self.vocab_size <= 0:
            raise ValueError("model dimensions must be positive")

    @classmethod
    def from_json(cls, path):
        with open(path, encoding="utf-8") as f:
            return cls(**json.load(f))

    def save(self, path):
        with open(path, "w", encoding="utf-8") as f:
            json.dump(asdict(self), f, indent=2)

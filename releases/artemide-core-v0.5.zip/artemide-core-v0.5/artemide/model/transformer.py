import math
import torch
from torch import nn
import torch.nn.functional as F

class RMSNorm(nn.Module):
    def __init__(self, dim, eps=1e-6):
        super().__init__()
        self.weight = nn.Parameter(torch.ones(dim))
        self.eps = eps
    def forward(self, x):
        return x * torch.rsqrt(x.pow(2).mean(-1, keepdim=True) + self.eps) * self.weight

def rotate_half(x):
    x1, x2 = x.chunk(2, dim=-1)
    return torch.cat((-x2, x1), dim=-1)

class RotaryEmbedding(nn.Module):
    def __init__(self, dim, theta=10000.0):
        super().__init__()
        inv = 1.0 / (theta ** (torch.arange(0, dim, 2).float() / dim))
        self.register_buffer("inv_freq", inv, persistent=False)
    def forward(self, x):
        t = torch.arange(x.shape[-2], device=x.device, dtype=self.inv_freq.dtype)
        freqs = torch.outer(t, self.inv_freq)
        emb = torch.cat((freqs, freqs), dim=-1)
        return emb.cos().to(x.dtype)[None,None,:,:], emb.sin().to(x.dtype)[None,None,:,:]

class Attention(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.head_dim = cfg.d_model // cfg.n_heads
        self.n_heads, self.n_kv_heads = cfg.n_heads, cfg.n_kv_heads
        self.q = nn.Linear(cfg.d_model, cfg.n_heads*self.head_dim, bias=False)
        self.k = nn.Linear(cfg.d_model, cfg.n_kv_heads*self.head_dim, bias=False)
        self.v = nn.Linear(cfg.d_model, cfg.n_kv_heads*self.head_dim, bias=False)
        self.out = nn.Linear(cfg.d_model, cfg.d_model, bias=False)
        self.rope = RotaryEmbedding(self.head_dim, cfg.rope_theta)
        self.dropout = cfg.dropout
    def forward(self, x):
        b,t,c = x.shape
        q = self.q(x).view(b,t,self.n_heads,self.head_dim).transpose(1,2)
        k = self.k(x).view(b,t,self.n_kv_heads,self.head_dim).transpose(1,2)
        v = self.v(x).view(b,t,self.n_kv_heads,self.head_dim).transpose(1,2)
        cos,sin = self.rope(q)
        q = q*cos + rotate_half(q)*sin
        k = k*cos + rotate_half(k)*sin
        if self.n_kv_heads != self.n_heads:
            repeat = self.n_heads // self.n_kv_heads
            k = k.repeat_interleave(repeat, dim=1)
            v = v.repeat_interleave(repeat, dim=1)
        y = F.scaled_dot_product_attention(q,k,v,is_causal=True,dropout_p=self.dropout if self.training else 0.0)
        return self.out(y.transpose(1,2).contiguous().view(b,t,c))

class SwiGLU(nn.Module):
    def __init__(self, dim):
        super().__init__()
        hidden = int(8*dim/3)
        self.gate = nn.Linear(dim, hidden, bias=False)
        self.up = nn.Linear(dim, hidden, bias=False)
        self.down = nn.Linear(hidden, dim, bias=False)
    def forward(self, x):
        return self.down(F.silu(self.gate(x))*self.up(x))

class Block(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.attn_norm, self.ffn_norm = RMSNorm(cfg.d_model), RMSNorm(cfg.d_model)
        self.attn, self.ffn = Attention(cfg), SwiGLU(cfg.d_model)
        self.resid_scale = 1 / math.sqrt(2*cfg.n_layers)
    def forward(self, x):
        x = x + self.attn(self.attn_norm(x))*self.resid_scale
        return x + self.ffn(self.ffn_norm(x))*self.resid_scale

class ArtemideLM(nn.Module):
    def __init__(self, cfg):
        super().__init__()
        self.cfg = cfg
        self.embed = nn.Embedding(cfg.vocab_size, cfg.d_model)
        self.layers = nn.ModuleList([Block(cfg) for _ in range(cfg.n_layers)])
        self.norm = RMSNorm(cfg.d_model)
        self.lm_head = nn.Linear(cfg.d_model, cfg.vocab_size, bias=False)
        self.lm_head.weight = self.embed.weight
        self.apply(self._init)
    def _init(self, m):
        if isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
        elif isinstance(m, nn.Embedding):
            nn.init.normal_(m.weight, mean=0.0, std=0.02)
    def forward(self, idx, targets=None):
        x = self.embed(idx)
        for layer in self.layers:
            x = layer(x)
        logits = self.lm_head(self.norm(x))
        loss = None
        if targets is not None:
            loss = F.cross_entropy(logits.reshape(-1, logits.size(-1)), targets.reshape(-1))
        return logits, loss
    @torch.no_grad()
    def generate(self, idx, max_new_tokens=64, temperature=1.0, top_k=None):
        for _ in range(max_new_tokens):
            logits,_ = self(idx[:, -self.cfg.max_seq_len:])
            logits = logits[:,-1,:] / max(temperature, 1e-5)
            if top_k:
                vals, _ = torch.topk(logits, min(top_k, logits.size(-1)))
                logits[logits < vals[:,-1,None]] = -float("inf")
            idx = torch.cat((idx, torch.multinomial(torch.softmax(logits, -1), 1)), dim=1)
        return idx

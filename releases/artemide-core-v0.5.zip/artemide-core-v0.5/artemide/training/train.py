import argparse, torch
from artemide.model.config import ModelConfig
from artemide.model.transformer import ArtemideLM
from artemide.training.checkpoint import save_checkpoint
from artemide.training.scheduler import lr_at_step
from artemide.training.telemetry import Telemetry

def main():
    p=argparse.ArgumentParser(description="Minimal Artemide random-init training loop")
    p.add_argument("--config",required=True); p.add_argument("--steps",type=int,default=100)
    p.add_argument("--batch-size",type=int,default=8); p.add_argument("--seq-len",type=int,default=128)
    p.add_argument("--lr",type=float,default=3e-4); p.add_argument("--warmup",type=int,default=10)
    p.add_argument("--min-lr",type=float,default=3e-5); p.add_argument("--device",default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--out",default="runs"); a=p.parse_args()
    cfg=ModelConfig.from_json(a.config); model=ArtemideLM(cfg).to(a.device); opt=torch.optim.AdamW(model.parameters(),lr=a.lr)
    telemetry=Telemetry(a.out+"/metrics.jsonl")
    for step in range(a.steps):
        x=torch.randint(0,cfg.vocab_size,(a.batch_size,a.seq_len),device=a.device)
        y=torch.roll(x,-1,dims=1); lr=lr_at_step(step,a.warmup,a.steps,a.lr,a.min_lr)
        for g in opt.param_groups: g["lr"]=lr
        _,loss=model(x,y); opt.zero_grad(set_to_none=True); loss.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(),1.0); opt.step()
        telemetry.log(step=step,train_loss=float(loss),learning_rate=lr,tokens_per_second=a.batch_size*a.seq_len)
        if (step+1)%50==0 or step+1==a.steps: save_checkpoint(a.out+"/latest.pt",model,opt,step+1)
    save_checkpoint(a.out+"/final.pt",model,opt,a.steps)
if __name__=="__main__": main()

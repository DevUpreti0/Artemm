import json, hashlib, random
from pathlib import Path

def load_texts(path):
    p=Path(path); docs=[]
    files=[p] if p.is_file() else sorted(p.rglob("*"))
    for f in files:
        if not f.is_file() or f.suffix.lower() not in {".txt",".jsonl"}: continue
        if f.suffix.lower()==".txt":
            s=f.read_text(encoding="utf-8",errors="replace").strip()
            if s: docs.append(s)
        else:
            for line in f.read_text(encoding="utf-8",errors="replace").splitlines():
                try:
                    obj=json.loads(line); s=obj.get("text","")
                    if isinstance(s,str) and s.strip(): docs.append(s.strip())
                except json.JSONDecodeError: continue
    return list(dict.fromkeys(docs))

def split_documents(docs, val_fraction=0.05, seed=42):
    docs=list(docs); random.Random(seed).shuffle(docs)
    n=max(1, int(len(docs)*val_fraction)) if len(docs)>1 else 0
    return docs[n:], docs[:n]

def write_manifest(paths, output, license_name="unspecified"):
    rows=[]
    for name in paths:
        p=Path(name); rows.append({"source":str(p),"license":license_name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()})
    Path(output).write_text(json.dumps(rows,indent=2),encoding="utf-8")

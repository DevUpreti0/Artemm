import json, os, time
class Telemetry:
    def __init__(self,path):
        self.path=path; os.makedirs(os.path.dirname(path) or ".",exist_ok=True)
    def log(self, **metrics):
        row={"timestamp":time.time(),**metrics}
        with open(self.path,"a",encoding="utf-8") as f: f.write(json.dumps(row)+"\n")

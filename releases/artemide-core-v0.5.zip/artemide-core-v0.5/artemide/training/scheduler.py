import math
def lr_at_step(step, warmup_steps, total_steps, max_lr, min_lr):
    if total_steps <= 0: raise ValueError("total_steps must be positive")
    if step < warmup_steps:
        return max_lr * (step + 1) / max(1, warmup_steps)
    progress=min(1.0,max(0.0,(step-warmup_steps)/max(1,total_steps-warmup_steps)))
    return min_lr + 0.5*(max_lr-min_lr)*(1+math.cos(math.pi*progress))

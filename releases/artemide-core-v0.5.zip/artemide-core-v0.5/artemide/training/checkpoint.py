import os, torch
def save_checkpoint(path, model, optimizer=None, step=0, extra=None):
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    tmp=path+".tmp"
    payload={"model":model.state_dict(),"step":step,"extra":extra or {}}
    if optimizer is not None: payload["optimizer"]=optimizer.state_dict()
    torch.save(payload,tmp); os.replace(tmp,path)
def load_checkpoint(path, model, optimizer=None, map_location="cpu"):
    data=torch.load(path,map_location=map_location,weights_only=False)
    model.load_state_dict(data["model"])
    if optimizer is not None and "optimizer" in data: optimizer.load_state_dict(data["optimizer"])
    return data

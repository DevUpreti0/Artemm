import argparse, math, torch
from artemide.model.config import ModelConfig
from artemide.model.transformer import ArtemideLM
from artemide.training.checkpoint import load_checkpoint
from artemide.tokenizer import ByteTokenizer

@torch.no_grad()
def evaluate(model, text, device="cpu", seq_len=256):
    tok=ByteTokenizer(); ids=torch.tensor(tok.encode(text),dtype=torch.long,device=device)
    if ids.numel()<2: raise ValueError("evaluation text must contain at least two tokens")
    losses=[]
    for i in range(0, ids.numel()-1, seq_len):
        x=ids[i:i+seq_len].unsqueeze(0); y=ids[i+1:i+seq_len+1].unsqueeze(0)
        if x.numel()==0 or y.numel()==0: continue
        _,loss=model(x,y)
        losses.append(float(loss))
    mean=sum(losses)/len(losses)
    return {"loss":mean,"perplexity":math.exp(min(mean,80))}
def main():
    p=argparse.ArgumentParser(); p.add_argument("--config",required=True); p.add_argument("--checkpoint",required=True); p.add_argument("--text",required=True); p.add_argument("--device",default="cpu")
    a=p.parse_args(); cfg=ModelConfig.from_json(a.config); m=ArtemideLM(cfg).to(a.device)
    load_checkpoint(a.checkpoint,m,map_location=a.device); print(evaluate(m,open(a.text,encoding="utf-8").read(),a.device))
if __name__=="__main__": main()

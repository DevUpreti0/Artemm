from artemide.training.scheduler import lr_at_step
from artemide.training.telemetry import Telemetry
from pathlib import Path
import json

def test_schedule_warmup_and_decay():
    assert lr_at_step(0,10,100,1.0,0.1)==0.1
    assert lr_at_step(100,10,100,1.0,0.1)==0.1

def test_telemetry_jsonl(tmp_path):
    p=tmp_path/"metrics.jsonl"; t=Telemetry(str(p)); t.log(step=3,train_loss=1.25)
    row=json.loads(p.read_text().strip()); assert row["step"]==3 and row["train_loss"]==1.25

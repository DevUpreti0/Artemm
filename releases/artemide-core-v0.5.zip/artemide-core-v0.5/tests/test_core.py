import torch
from artemide.model import ModelConfig, ArtemideLM
from artemide.tokenizer import ByteTokenizer

def test_forward_shape_and_loss():
    cfg=ModelConfig(vocab_size=259,d_model=64,n_layers=2,n_heads=4,n_kv_heads=2,max_seq_len=32)
    m=ArtemideLM(cfg); x=torch.randint(0,259,(2,16))
    logits,loss=m(x,x)
    assert logits.shape==(2,16,259) and torch.isfinite(loss)

def test_byte_tokenizer_roundtrip():
    t=ByteTokenizer(); s="Artemide ✓"
    assert t.decode(t.encode(s))==s

def test_invalid_grouped_query_config():
    try: ModelConfig(d_model=64,n_heads=4,n_kv_heads=3)
    except ValueError: return
    assert False
